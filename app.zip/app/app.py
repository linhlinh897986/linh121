import os
import uuid
import json
import threading
import base64
import io
import queue
import imagehash
from io import BytesIO
from flask import Flask, request, jsonify
from PIL import Image
from concurrent.futures import ThreadPoolExecutor
import google.generativeai as genai

# Khởi tạo Flask app
app = Flask(__name__)

# File JSON và lock
JSON_FILE = "captcha_results.json"
lock = threading.Lock()

# Lấy đường dẫn thư mục hiện tại
current_directory = os.path.dirname(os.path.abspath(__file__))

# Đường dẫn tương đối đến thư mục images_captcha_serfclick
base_directory = os.path.join(current_directory, "images_captcha_serfclick")

# Khởi tạo ImageComparator
class ImageComparator:
    def __init__(self, base_directory, results_file):
        self.base_directory = base_directory
        self.results_file = results_file
        self.image_hashes = self.load_image_hashes()
        self.task_queue = queue.Queue()
        self.executor = ThreadPoolExecutor(max_workers=5)
        self.results = self.load_results()

    def load_results(self):
        if os.path.exists(self.results_file):
            with open(self.results_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def save_results(self):
        with open(self.results_file, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, ensure_ascii=False, indent=4)

    def base64_to_image(self, base64_string):
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        image_bytes = base64.b64decode(base64_string)
        return Image.open(io.BytesIO(image_bytes))

    def load_image_hashes(self):
        image_hashes = {}
        for folder in os.listdir(self.base_directory):
            folder_path = os.path.join(self.base_directory, folder)
            if os.path.isdir(folder_path):
                image_hashes[folder] = self.get_folder_image_hashes(folder_path)
        return image_hashes

    def get_folder_image_hashes(self, folder_path):
        folder_hashes = []
        for filename in os.listdir(folder_path):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                image_path = os.path.join(folder_path, filename)
                try:
                    with Image.open(image_path) as img:
                        folder_hashes.append(imagehash.phash(img))
                except Exception as e:
                    print(f"Lỗi khi xử lý ảnh {filename}: {e}")
        return folder_hashes

    def process_image_comparison(self, task_id, images, target_folder):
        try:
            matched_indices = self.compare_images(images, target_folder)
            self.results[task_id] = matched_indices
            self.save_results()
        except Exception as e:
            self.results[task_id] = None
            self.save_results()

    def compare_images(self, images, target_folder):
        if target_folder not in self.image_hashes:
            return None
        results = [0] * len(images)
        for index, image in enumerate(images, 1):
            image_hash = imagehash.phash(image)
            for ref_hash in self.image_hashes[target_folder]:
                if image_hash - ref_hash <= 5:
                    results[index - 1] = index
                    break
        return results

# Khởi tạo ImageComparator
comparator = ImageComparator(
    base_directory=base_directory,  # Sử dụng đường dẫn tương đối
    results_file='ket_qua.json'
)

# Hàm hỗ trợ
def load_data():
    if not os.path.exists(JSON_FILE):
        return {}
    with open(JSON_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(JSON_FILE, "w") as f:
        json.dump(data, data, indent=4)

def base64_to_image(base64_str):
    try:
        if "base64," in base64_str:
            base64_str = base64_str.split("base64,")[1]
        image_data = base64.b64decode(base64_str)
        return Image.open(BytesIO(image_data))
    except Exception as e:
        raise ValueError(f"Invalid base64 image: {str(e)}")

# Endpoint xử lý upload ảnh và gọi Gemini API
@app.route("/upload", methods=["POST"])
def upload_image():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    api_key = data.get("api_key")
    if not api_key:
        return jsonify({"error": "Missing API key"}), 401

    base64_image = data.get("image")
    if not base64_image:
        return jsonify({"error": "No image data provided"}), 400

    try:
        image = base64_to_image(base64_image)
        captcha_id = str(uuid.uuid4())

        with lock:
            data = load_data()
            data[captcha_id] = {"status": "processing", "result": None}
            save_data(data)

        threading.Thread(
            target=process_image_with_gemini,
            args=(image, captcha_id, api_key),
        ).start()

        return jsonify({"captcha_id": captcha_id})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

def process_image_with_gemini(image, captcha_id, api_key):
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-1.5-flash")
        buffered = BytesIO()
        image.save(buffered, format="PNG")
        image_data = buffered.getvalue()
        response = model.generate_content(["Extract text", {"mime_type": "image/png", "data": image_data}])

        with lock:
            data = load_data()
            if captcha_id in data:
                data[captcha_id]["status"] = "completed"
                data[captcha_id]["result"] = response.text
                save_data(data)
    except Exception as e:
        with lock:
            data = load_data()
            if captcha_id in data:
                data[captcha_id]["status"] = "error"
                data[captcha_id]["result"] = str(e)
                save_data(data)

# Endpoint lấy kết quả từ Gemini API
@app.route("/result/<captcha_id>", methods=["GET"])
def get_result(captcha_id):
    with lock:
        data = load_data()
        result = data.get(captcha_id)
    
    if not result:
        return jsonify({"error": "Invalid Captcha ID"}), 404
    
    return jsonify(result)

# Endpoint gửi tác vụ so sánh hình ảnh
@app.route('/submit_task', methods=['POST'])
def submit_task():
    try:
        task_id = str(uuid.uuid4())
        data = request.json
        folder_name = data.get('ten_thu_muc')
        images = []
        for i in range(1, 7):
            body_key = f'body{i}'
            if body_key in data:
                images.append(comparator.base64_to_image(data[body_key]))
        
        if not folder_name or not images:
            return jsonify({'error': 'Thiếu thông tin'}), 400

        comparator.executor.submit(
            comparator.process_image_comparison, 
            task_id, 
            images, 
            folder_name
        )

        return jsonify({'task_id': task_id})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Endpoint lấy kết quả so sánh hình ảnh
@app.route('/get_result/<task_id>', methods=['GET'])
def get_comparison_result(task_id):
    if task_id in comparator.results:
        result = comparator.results[task_id]
        return ','.join(map(str, result))
    return jsonify({'error': 'Không tìm thấy kết quả'}), 404

# Chạy ứng dụng
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)