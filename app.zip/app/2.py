import os
import uuid
import json
import base64
import io
import threading
import queue
import imagehash
from PIL import Image
from flask import Flask, request, jsonify
from concurrent.futures import ThreadPoolExecutor

class ImageComparator:
    def __init__(self, base_directory, results_file):
        """
        Khởi tạo hệ thống so sánh hình ảnh với quản lý đa luồng

        Args:
            base_directory (str): Thư mục chứa các thư mục hình ảnh
            results_file (str): Đường dẫn đến file JSON lưu trữ kết quả
        """
        self.base_directory = base_directory
        self.results_file = results_file
        self.image_hashes = self.load_image_hashes()
        self.task_queue = queue.Queue()
        self.executor = ThreadPoolExecutor(max_workers=5)
        self.results = self.load_results()

    def load_results(self):
        """Tải kết quả đã lưu từ file JSON"""
        if os.path.exists(self.results_file):
            with open(self.results_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def save_results(self):
        """Lưu toàn bộ kết quả vào file JSON"""
        with open(self.results_file, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, ensure_ascii=False, indent=4)

    def base64_to_image(self, base64_string):
        """
        Chuyển đổi chuỗi base64 thành đối tượng PIL Image
        
        Args:
            base64_string (str): Chuỗi base64 của hình ảnh
        
        Returns:
            PIL.Image: Đối tượng hình ảnh
        """
        # Loại bỏ phần header của base64 nếu có
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        # Giải mã base64
        image_bytes = base64.b64decode(base64_string)
        
        # Chuyển đổi thành đối tượng PIL Image
        return Image.open(io.BytesIO(image_bytes))

    def load_image_hashes(self):
        """Tải hash của tất cả các hình ảnh từ các thư mục con"""
        image_hashes = {}
        for folder in os.listdir(self.base_directory):
            folder_path = os.path.join(self.base_directory, folder)
            if os.path.isdir(folder_path):
                image_hashes[folder] = self.get_folder_image_hashes(folder_path)
        return image_hashes

    def get_folder_image_hashes(self, folder_path):
        """Lấy hash của các hình ảnh trong một thư mục"""
        folder_hashes = []
        for filename in os.listdir(folder_path):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
                image_path = os.path.join(folder_path, filename)
                try:
                    with Image.open(image_path) as img:
                        folder_hashes.append(imagehash.phash(img))
                except Exception as e:
                    print(f"Lỗi khi xử lý ảnh {filename}: {e}")
        return folder_hashes

    def process_image_comparison(self, task_id, images, target_folder):
        """
        Xử lý so sánh hình ảnh trong một luồng riêng.
        Trả về danh sách chỉ số của các ảnh trùng khớp.
        """
        try:
            matched_indices = self.compare_images(images, target_folder)
            # Lưu kết quả vào bộ nhớ và file JSON
            self.results[task_id] = matched_indices
            self.save_results()

        except Exception as e:
            self.results[task_id] = None
            self.save_results()

    def compare_images(self, images, target_folder):
        """So sánh các hình ảnh được gửi với các hình ảnh trong thư mục đích"""
        if target_folder not in self.image_hashes:
            return None

        results = [0] * len(images)  # Khởi tạo danh sách kết quả với giá trị mặc định là 0
        for index, image in enumerate(images, 1):
            image_hash = imagehash.phash(image)
            for ref_hash in self.image_hashes[target_folder]:
                if image_hash - ref_hash <= 5:
                    results[index - 1] = index  # Đánh dấu chỉ số ảnh nếu khớp
                    break

        return results

# Khởi tạo Flask app và ImageComparator
app = Flask(__name__)
comparator = ImageComparator(
    base_directory='C:\\Users\\Administrator\\Desktop\\images_captcha_serfclick', 
    results_file='ket_qua.json'
)

@app.route('/submit_task', methods=['POST'])
def submit_task():
    """
    Endpoint để gửi tác vụ so sánh hình ảnh
    Trả về ID captcha để truy vấn kết quả
    """
    try:
        # Sinh ra ID captcha duy nhất
        task_id = str(uuid.uuid4())
        
        # Lấy dữ liệu từ request
        data = request.json
        folder_name = data.get('ten_thu_muc')
        
        # Xử lý hình ảnh base64
        images = []
        for i in range(1, 7):
            body_key = f'body{i}'
            if body_key in data:
                images.append(comparator.base64_to_image(data[body_key]))
        
        # Kiểm tra tính hợp lệ của dữ liệu
        if not folder_name or not images:
            return jsonify({'error': 'Thiếu thông tin'}), 400

        # Gửi tác vụ vào luồng xử lý
        comparator.executor.submit(
            comparator.process_image_comparison, 
            task_id, 
            images, 
            folder_name
        )

        return jsonify({'task_id': task_id})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_result/<task_id>', methods=['GET'])
def get_result(task_id):
    """
    Endpoint để lấy kết quả từ ID captcha.
    Trả về kết quả dưới dạng chuỗi '1,5,0,0,0'.
    """
    # Kiểm tra kết quả trong bộ nhớ
    if task_id in comparator.results:
        # Lấy kết quả dạng danh sách và chuyển thành chuỗi
        result = comparator.results[task_id]
        return ','.join(map(str, result))
    
    return jsonify({'error': 'Không tìm thấy kết quả'}), 404



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
